package model;

public enum TipoUsuario {
	
	EMPLEADO,
	CLIENTE

}
