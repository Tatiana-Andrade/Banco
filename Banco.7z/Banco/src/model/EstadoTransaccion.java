package model;

public enum EstadoTransaccion {

    EXITOSA,
    RECHAZADO,
    SINFONDO

}
