package model;

public enum TipoCuenta {
    AHORRO,
    CORRIENTE,
}
