package model;

public enum TipoTransaccion {
	DEPOSITO,
	RETIRO

}
